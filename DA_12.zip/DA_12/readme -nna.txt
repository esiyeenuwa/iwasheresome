DA_php are device atlas php API. 
The device data is contained in "20080617.json" and is the developper version.

The two above are used together.


The thrid file:
ia.zip is for image adaptation. Can convert images on the fly.

see http://dev.mobi/article/image-adaptation-with-deviceatlas
(will have to be used in conjuction with previous two files)
Need to configure this latter one to see location of prevoius files. Requires php 5.2.3+

